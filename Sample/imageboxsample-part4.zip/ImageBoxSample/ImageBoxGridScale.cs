﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cyotek.Windows.Forms
{
  public enum ImageBoxGridScale
  {
    Small,
    Medium,
    Large
  }
}
