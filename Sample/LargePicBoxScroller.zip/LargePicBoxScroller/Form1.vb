﻿Public Class Form1
    Private Structure Selection
        Public Top As Integer
        Public Left As Integer
        Public Height As Integer
        Public Width As Integer
    End Structure

    Private wEdge As Boolean
    Private eEdge As Boolean
    Private nEdge As Boolean
    Private sEdge As Boolean
    Private Sizing As Boolean
    Private Const EdgeSize As Integer = 6
    Private StartCord As Drawing.Point
    Private OldCord As Drawing.Point
    Private newCord As Drawing.Point
    Private Rect As Selection
    Private MovePic As Boolean
    Private MoveMain As Boolean
    Private SizePic As Boolean

    Public Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' This is very important .........
        PictureBox2.Parent = PictureBox1
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.Parent = PictureBox2
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage


    End Sub

    Private Sub ScrollAdjust()
        'used for resizing the parent form & holder !!
        With PictureBox2
            If .Width < PictureBox1.Width Then
                .Left = (PictureBox1.Width - .Width) / 2
                HScrollBar1.Enabled = False
            Else
                If .Left > 0 Then .Left = 0
                HScrollBar1.Minimum = 0
                HScrollBar1.Maximum = .Width - PictureBox1.Width
                HScrollBar1.SmallChange = 1
                HScrollBar1.LargeChange = 10
                HScrollBar1.Enabled = True
            End If
            If .Height < PictureBox1.Height Then
                .Top = (PictureBox1.Height - .Height) / 2
                VScrollBar1.Enabled = False
            Else
                If .Top > 0 Then .Top = 0
                VScrollBar1.Minimum = 0
                VScrollBar1.Maximum = .Height - PictureBox1.Height
                VScrollBar1.SmallChange = 1
                VScrollBar1.LargeChange = 10
                VScrollBar1.Enabled = True
            End If
        End With
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        ScrollAdjust()
    End Sub

    Private Sub VScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles VScrollBar1.Scroll
        PictureBox2.Top = -VScrollBar1.Value

    End Sub

    Private Sub HScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar1.Scroll
        PictureBox2.Left = -HScrollBar1.Value

    End Sub


    Private Sub PictureBox3_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox3.MouseDown
        ' Click on Sizable Image Region - NB. Child picturebox
        If e.Button = Windows.Forms.MouseButtons.Left Then
            OldCord = e.Location
            StartCord = e.Location
            If Sizing Then
                SizePic = True
            Else
                MovePic = True
            End If
        End If
        If e.Button = Windows.Forms.MouseButtons.Middle Then
            MoveMain = True
            StartCord = e.Location
        End If

    End Sub

    Private Sub PictureBox3_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox3.MouseMove
        ' Mouse move inside Image Region... - NB. Child Picturebox
        If e.Button = Windows.Forms.MouseButtons.None Then
            If e.Location.X < EdgeSize And e.Location.X > 0 Then
                wEdge = True
            Else
                wEdge = False
            End If
            If e.Location.X > PictureBox3.Size.Width - EdgeSize And e.Location.X < PictureBox3.Size.Width Then
                eEdge = True
            Else
                eEdge = False
            End If
            If e.Location.Y < EdgeSize And e.Location.Y > 0 Then
                nEdge = True
            Else
                nEdge = False
            End If
            If e.Location.Y > PictureBox3.Size.Height - EdgeSize And e.Location.Y < PictureBox3.Size.Height Then
                sEdge = True
            Else
                sEdge = False
            End If
            Sizing = True
        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then
            If MovePic Then
                PictureBox3.Top = PictureBox3.Top + (e.Location.Y - StartCord.Y)
                PictureBox3.Left = PictureBox3.Left + (e.Location.X - StartCord.X)
            End If
            ' The code following works when used with a child Picturebox...
            ' NB. Alternate code will apply if working on a rect region selection.....
            If SizePic Then
                Rect.Top = PictureBox3.Top
                Rect.Height = PictureBox3.Height
                Rect.Left = PictureBox3.Left
                Rect.Width = PictureBox3.Width
                If eEdge Then
                    Rect.Width = e.Location.X
                End If
                If sEdge Then
                    Rect.Height = e.Location.Y
                End If
                If wEdge Then
                    Rect.Left = Rect.Left - (StartCord.X - e.Location.X)
                    Rect.Width = Rect.Width + (StartCord.X - e.Location.X)
                End If
                If nEdge Then
                    Rect.Top = Rect.Top - (StartCord.Y - e.Location.Y)
                    Rect.Height = Rect.Height + (StartCord.Y - e.Location.Y)
                End If
                If Rect.Height < 0 Then
                    Rect.Top = Rect.Top + Rect.Height
                    Rect.Height = Math.Abs(Rect.Height)
                    nEdge = Not nEdge
                    sEdge = Not sEdge
                    StartCord.Y = 0
                End If
                If Rect.Width < 0 Then
                    Rect.Left = Rect.Left + Rect.Width
                    Rect.Width = Math.Abs(Rect.Width)
                    eEdge = Not eEdge
                    wEdge = Not wEdge
                    StartCord.X = 0
                End If
                PictureBox3.Top = Rect.Top
                PictureBox3.Height = Rect.Height
                PictureBox3.Left = Rect.Left
                PictureBox3.Width = Rect.Width
            End If
        End If
        If (nEdge Or sEdge) And Not (wEdge Or eEdge) Then
            PictureBox3.Cursor = Cursors.SizeNS
        ElseIf (wEdge Or eEdge) And Not (nEdge Or sEdge) Then
            PictureBox3.Cursor = Cursors.SizeWE
        ElseIf (nEdge And eEdge) Or (sEdge And wEdge) Then
            PictureBox3.Cursor = Cursors.SizeNESW
        ElseIf (nEdge And wEdge) Or (sEdge And eEdge) Then
            PictureBox3.Cursor = Cursors.SizeNWSE
        Else
            PictureBox3.Cursor = Cursors.Default
            Sizing = False
        End If

        OldCord = e.Location
        If MoveMain Then
            PictureBox2_MouseMove(sender, e)
        End If
    End Sub

    Private Sub PictureBox3_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox3.MouseUp
        ' Release Click in Sizable Image Region - NB. Child picturebox
        SizePic = False
        MovePic = False
        MoveMain = False
    End Sub

    Private Sub PictureBox2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Middle Then
            MoveMain = True
            StartCord = e.Location
        End If
    End Sub

    Private Sub PictureBox2_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseMove
        If MoveMain Then
            If VScrollBar1.Enabled Then
                newCord.Y = PictureBox2.Top - (StartCord.Y - e.Location.Y)
                If newCord.Y > 0 Then newCord.Y = 0
                If newCord.Y < -VScrollBar1.Maximum Then newCord.Y = -VScrollBar1.Maximum
                PictureBox2.Top = newCord.Y
                VScrollBar1.Value = -newCord.Y
            End If
            If HScrollBar1.Enabled Then
                newCord.X = PictureBox2.Left - (StartCord.X - e.Location.X)
                If newCord.X > 0 Then newCord.X = 0
                If newCord.X < -HScrollBar1.Maximum Then newCord.X = -HScrollBar1.Maximum
                PictureBox2.Left = newCord.X
                HScrollBar1.Value = -newCord.X
            End If
        End If
    End Sub

    Private Sub PictureBox2_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseUp
        MoveMain = False
    End Sub
End Class
