﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cyotek ImageBox Control")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Cyotek Ltd")]
[assembly: AssemblyProduct("Cyotek ImageBox Control")]
[assembly: AssemblyCopyright("Copyright © 2010-2017 Cyotek Ltd.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d812a438-008c-47f9-926f-8415490cdda1")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.0.0")]
[assembly: AssemblyInformationalVersion("1.2.1")]
